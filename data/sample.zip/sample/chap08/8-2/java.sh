export JAVA_HOME=/usr/java/jdk1.6.0_31
export PATH=\$PATH:\$JAVA_HOME/bin
