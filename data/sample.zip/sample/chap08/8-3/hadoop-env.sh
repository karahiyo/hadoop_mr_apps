export HADOOP_MAPRED_HOME=/usr/lib/hadoop-mapreduce
