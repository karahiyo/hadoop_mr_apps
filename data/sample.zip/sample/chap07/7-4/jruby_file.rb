puts "start"
list
if 0 == 0 then java.lang.System.out.println("end") end
exit
